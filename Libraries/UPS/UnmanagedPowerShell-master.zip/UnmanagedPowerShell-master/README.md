UnmanagedPowerShell
===================

Executes PowerShell from an unmanaged process.  With a few modifications, these same techniques can be used when injecting into different processes (i.e. you can cause any process to execute PowerShell if you want).
